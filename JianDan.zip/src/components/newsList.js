import React, {
	Component
} from "react"
import {
	connect
} from "react-redux";
import {
	StyleSheet,
	View,
	Text,
	ListView,
	Platform,
	ProgressBarAndroid,
	ToastAndroid
} from "react-native";
import NewsItem from './newsItem';
import NewsDetail from './drawerList';
import LoadingMore from './loadingMore';

class NewsList extends Component {

	constructor(props) {
		super(props);
		this.state = {
			dataSource: new ListView.DataSource({
				rowHasChanged: (row1, row2) => row1 !== row2,
			}),
		};

	}

	render() {
		let {
			news
		} = this.props;
		let content = < ListView ref = "listview"
		dataSource = {
			this.state.dataSource.cloneWithRows(news)
		}
		renderRow = {
			(item) => this.renderRow(item)
		}
		onEndReached = {
			this.props.getNext
		}
		renderFooter = {
			() => this.renderFooter()
		}
		enableEmptySections = {
			true
		}
		automaticallyAdjustContentInsets = {
			false
		}
		keyboardDismissMode = "on-drag"
		keyboardShouldPersistTaps = {
			true
		}
		refreshControl = {
			<RefreshControl
						              refreshing={this.state.isRefreshing}
						              onRefresh={()=>this.onRefresh()}
						              colors={['#272822']}/>
		}
		/>;
		return (<View style={styles.container}>{content}</View>);
	}

	renderRow(item) {
		return (
			<NewsItem
		            onSelect={()=>this.selectMovie(item)}
		            item={item}/>
		);
	}

	renderFooter() {
		return (<LoadingMore />);
	}

	onRefresh() {

	}


	selectMovie(movie) {
		this.props.navigator.push({
			name: 'news',
			component: NewsDetail,

		});

	}


}


var styles = StyleSheet.create({
	container: {
		flex: 1
	},
	scrollSpinner: {
		marginVertical: 20,
	},
});


export default NewsList;