export const NEWS = "新鲜事";
export const TREE_NEW_BEE = "段子";
export const PICTURES = "无聊图 ";
export const GIRLS = "妹子图";
export const VIDEOS = "小电影";
export const SETTING = "设置";