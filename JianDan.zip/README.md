# JianDan_Redux
JanDan+React Native +Redux
<p>splash.js=>hello react native.js
